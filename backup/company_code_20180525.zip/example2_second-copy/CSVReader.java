package com.wuerth.phoenix.cis.university.example2.test.lemon;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

import com.wuerth.phoenix.cis.university.example2.test.IEngineTestData;
import com.wuerth.phoenix.cis.university.example2.util.*;

import com.wuerth.phoenix.cis.university.example2.adapters.*;

public class CSVReader {

	public static ArrayList<InputCombination> ReadScenarios(String csvPath) {
		ArrayList<InputCombination> allInputs = new ArrayList<InputCombination>();
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String entrySplitBy = ";";
		String parametersSplitBy = "\\*";
		boolean isHeader = true;
		HashSet<ConcreteAccount> concreteAccounts = Util.getAllConcreteAccount();
		List<IFRS16ImportAssignmentType> allTypes = IFRS16ImportAssignmentType.getAllValues();

		try {

			br = new BufferedReader(new FileReader(csvPath));

			while ((line = br.readLine()) != null) {
				if (isHeader) {
					isHeader = false;
					continue;
				}
				try {

					ArrayList<Company> companyList = new ArrayList<Company>();
					String[] splitLine = line.split(cvsSplitBy);

					String settingsName = splitLine[0];
					String localeString = splitLine[1];
					String groupSymbolString = splitLine[2]; // should be the name in all caps, e.g. "COMMA".
					String separatorSymbolString = splitLine[3]; // same as above
					String dateFormat = splitLine[4];
					String filePath = splitLine[5];
					String isLongVersionString = splitLine[6]; // true or false as strings
					String yearString = splitLine[7];
					String monthString = splitLine[8];
					String[] codeList = splitLine[9].split(entrySplitBy);
					String[] combinationsList = splitLine[10].split(entrySplitBy);

					boolean isLongVersion = true;
					if (!isLongVersionString.isEmpty()) {
						isLongVersion = Boolean.valueOf(isLongVersionString);
					}

					Locale currentLocale = null;
					DigitGroupingSymbol digitGroupingSymbol = DigitGroupingSymbol.NULL;
					DigitGroupingSymbol decimalSeparator = DigitGroupingSymbol.NULL;
					for (Locale l : Locale.getAvailableLocales()) {
						if (l.toString().equals(localeString)) { // valid values: 'en' and 'de'.
							currentLocale = l;
							break;
						}
					}
					switch (groupSymbolString) {
					case "POINT":
						digitGroupingSymbol = DigitGroupingSymbol.POINT;
						break;
					case "COMMA":
						digitGroupingSymbol = DigitGroupingSymbol.COMMA;
						break;
					case "NO_BREAK_SPACE":
						digitGroupingSymbol = DigitGroupingSymbol.NO_BREAK_SPACE;
						break;
					case "SINGLE_QUOTATION_MARK":
						digitGroupingSymbol = DigitGroupingSymbol.SINGLE_QUOTATION_MARK;
						break;
					case "NORMAL_SPACE":
						digitGroupingSymbol = DigitGroupingSymbol.NORMAL_SPACE;
						break;
					default:
						digitGroupingSymbol = DigitGroupingSymbol.NULL;
						break;
					}
					switch (separatorSymbolString) {
					case "POINT":
						decimalSeparator = DigitGroupingSymbol.POINT;
						break;
					case "COMMA":
						decimalSeparator = DigitGroupingSymbol.COMMA;
						break;
					case "NO_BREAK_SPACE":
						decimalSeparator = DigitGroupingSymbol.NO_BREAK_SPACE;
						break;
					case "SINGLE_QUOTATION_MARK":
						decimalSeparator = DigitGroupingSymbol.SINGLE_QUOTATION_MARK;
						break;
					case "NORMAL_SPACE":
						decimalSeparator = DigitGroupingSymbol.NORMAL_SPACE;
						break;
					default:
						decimalSeparator = DigitGroupingSymbol.NULL;
						break;
					}

					Settings settings = new Settings(currentLocale, digitGroupingSymbol, decimalSeparator, dateFormat);
					//settings.getTypeList().addAll(allTypes);
					settings.setName(settingsName);
					settings.setFilePath(filePath);
					settings.setLongVersion(isLongVersion);
					if (!yearString.isEmpty()) {
						try {

							settings.setYear(Integer.valueOf(yearString));
						} catch (Exception e) {

						}
					}
					if (!monthString.isEmpty()) {
						try {
							settings.setMonth(Integer.valueOf(monthString));
						} catch (Exception e) {

						}
					}

					for (String code : codeList) {
						// one of these companies is used a target -> target for an import
						Company company = new Company();
						company.setCode(code);
						companyList.add(company);
					}
					
					ArrayList<CombinationLine> combinationLines = new ArrayList<CombinationLine>();
					for (String inputLine : combinationsList) {
						String[] inputValues = inputLine.split(parametersSplitBy);
						if(inputValues.length<20) {
							System.out.println("Combination input too short");
							System.out.println(inputLine);
							continue;
						}
						CombinationLine combinationLine = new CombinationLine();
						HashMap<IFRS16ImportAssignmentType, CombinationItem<?>> values = new HashMap<IFRS16ImportAssignmentType, CombinationItem<?>>();

						if (inputValues[0] != null && !inputValues[0].trim().isEmpty()) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.CONTRACTNUMBER);
							CombinationItem<String> iContractNumber = CombinationItem
									.getNewCombinationItem(inputValues[0]);
							values.put(IFRS16ImportAssignmentType.CONTRACTNUMBER, iContractNumber);
						}
						if (inputValues[1] != null && !inputValues[1].trim().isEmpty()) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.CREDITORNUMBER);
							CombinationItem<String> icreditorNr = CombinationItem.getNewCombinationItem(inputValues[1]);
							values.put(IFRS16ImportAssignmentType.CREDITORNUMBER, icreditorNr);
						}
						if (inputValues[2] != null && !inputValues[2].trim().isEmpty()) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.CREDITORNAME);
							CombinationItem<String> iContractName = CombinationItem
									.getNewCombinationItem(inputValues[2]);
							values.put(IFRS16ImportAssignmentType.CREDITORNAME, iContractName);
						}
						/*
						 * for concreteaccount input, one of the following strings:
						 * IFRS16_RIGHT_OF_USE_LAND_OFFICES, IFRS16_RIGHT_OF_USE_LAND_RESIDENTIALS,
						 * IFRS16_RIGHT_OF_USE_LAND_NO_BUILDINGS, IFRS16_RIGHT_OF_USE_BUILDINGS,
						 * IFRS16_RIGHT_OF_USE_TECHNICAL_EQUIPMENT, IFRS16_RIGHT_OF_USE_EQUIPMENT,
						 * IFRS16_RIGHT_OF_USE_VEHICLE_FLEET
						 * 
						 */

						if (inputValues[3] != null && !inputValues[3].isEmpty()) {
							ConcreteAccount concrAcc = null;
							for (ConcreteAccount acc : concreteAccounts) {
								if (acc.getCode().equals(inputValues[3])) {
									concrAcc = acc;
									break;
								}
							}
							if (concrAcc != null) {
								settings.getTypeList().add(IFRS16ImportAssignmentType.GROUPPOSITION);
								CombinationItem<ConcreteAccount> iconcreteAccount = CombinationItem
										.getNewCombinationItem(concrAcc, settings); // not
								// sure
								// about
								// this
								// one
								values.put(IFRS16ImportAssignmentType.GROUPPOSITION, iconcreteAccount);

							}
						}
						if (inputValues[4] != null && !inputValues[4].trim().isEmpty()) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.DESIGNATIONLEASEDOBJECT);
							CombinationItem<String> desLeasObj = CombinationItem.getNewCombinationItem(inputValues[4]);
							values.put(IFRS16ImportAssignmentType.DESIGNATIONLEASEDOBJECT, desLeasObj);
						}
						if (inputValues[5] != null && !inputValues[5].trim().isEmpty()) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.STARTDATEOFCONTRACT);
							CombinationItem<String> startDateContr = CombinationItem
									.getNewCombinationItem(inputValues[5]);
							values.put(IFRS16ImportAssignmentType.STARTDATEOFCONTRACT, startDateContr);
						}
						if (inputValues[6] != null && !inputValues[6].trim().isEmpty()) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.ENDDATEOFCONTRACT);
							CombinationItem<String> endDateContr = CombinationItem
									.getNewCombinationItem(inputValues[6]);
							values.put(IFRS16ImportAssignmentType.ENDDATEOFCONTRACT, endDateContr);
						}
						if (inputValues[7] != null && !inputValues[7].trim().isEmpty()) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.PROBABLEENDOFCONTRACT);
							CombinationItem<String> probEndContr = CombinationItem
									.getNewCombinationItem(inputValues[7]);
//							CombinationItem<String> probEndContr = ;
							values.put(IFRS16ImportAssignmentType.PROBABLEENDOFCONTRACT, probEndContr);
						}
						Double interestRate = null;
						try {
							interestRate = Double.valueOf(inputValues[8]);
						} catch (Exception ex) {
							System.out.println(ex);
						}
						if (interestRate != null) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.INTERESTRATE);
							CombinationItem<Double> intRate = CombinationItem.getNewCombinationItem(interestRate,
									settings);
							values.put(IFRS16ImportAssignmentType.INTERESTRATE, intRate);
						}
						if (inputValues[9] != null && !inputValues[9].trim().isEmpty()) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.PARTNERCOMPANY);
							CombinationItem<String> partnerComp = CombinationItem.getNewCombinationItem(inputValues[9]);
							values.put(IFRS16ImportAssignmentType.PARTNERCOMPANY, partnerComp);
						}
						
						IFRS16ConditionType iConditionType = null;
						if(inputValues[10]!=null) {
							try {
								iConditionType = new IFRS16ConditionType(inputValues[10], Boolean.valueOf(inputValues[11]));
							}
							catch(Exception e) {
								
							}
							
						}
						
//						if(iConditionType!=null) {
//							settings.getTypeList().add(IFRS16ImportAssignmentType.CONDITIONTYPE);
//							CombinationItem<IFRS16ConditionType> conditionType = CombinationItem.getNewCombinationItem(iConditionType,
//									settings);
//							values.put(IFRS16ImportAssignmentType.CONDITIONTYPE, conditionType);
//						}
//						
						Long fromDate = null;
						try {
							fromDate = Long.valueOf(inputValues[12]);
						} catch (Exception ex) {

						}
						if (fromDate != null) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.FROMDATE);
							CombinationItem<Long> fromDateItem = CombinationItem.getNewCombinationItem(fromDate,
									settings);
							values.put(IFRS16ImportAssignmentType.FROMDATE, fromDateItem);
						}
						Long tillDate = null;
						try {
							tillDate = Long.valueOf(inputValues[13]);
						} catch (Exception ex) {

						}
						if (tillDate != null) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.UNTILDATE);
							CombinationItem<Long> untilDate = CombinationItem.getNewCombinationItem(tillDate, settings);
							values.put(IFRS16ImportAssignmentType.UNTILDATE, untilDate);
						}
						if (inputValues[14] != null && !inputValues[14].trim().isEmpty()) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.COSTCENTER);
							CombinationItem<String> constCenter = CombinationItem
									.getNewCombinationItem(inputValues[14]);
							values.put(IFRS16ImportAssignmentType.COSTCENTER, constCenter);
						}
						IFRS16PaymentCycle iPaymentCycle = null; // maybe this should be
																	// iPaymentCycle.NULL ?
						switch (inputValues[15]) {
						case "NULL":
							iPaymentCycle = IFRS16PaymentCycle.NULL;
							break;
						case "NONRECURRING":
							iPaymentCycle = IFRS16PaymentCycle.NONRECURRING;
							break;
						case "MONTHLY":
							iPaymentCycle = IFRS16PaymentCycle.MONTHLY;
							break;
						case "QUARTERLY":
							iPaymentCycle = IFRS16PaymentCycle.QUARTERLY;
							break;
						case "SEMIANNUALLY":
							iPaymentCycle = IFRS16PaymentCycle.SEMIANNUALLY;
							break;
						case "ANNUALLY":
							iPaymentCycle = IFRS16PaymentCycle.ANNUALLY;
							break;
						}
						if (iPaymentCycle != null) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.PAYMENTCYCLE);
							CombinationItem<IFRS16PaymentCycle> paymentCycle = CombinationItem
									.getNewCombinationItem(iPaymentCycle, settings);
							values.put(IFRS16ImportAssignmentType.PAYMENTCYCLE, paymentCycle);
						}

						IFRS16PaymentDateType iPaymentDateType = null;
						switch (inputValues[16]) {
						case "NULL":
							iPaymentDateType = IFRS16PaymentDateType.NULL;
							break;
						case "INADVANCE":
							iPaymentDateType = IFRS16PaymentDateType.INADVANCE;
							break;
						case "MIDTERM":
							iPaymentDateType = IFRS16PaymentDateType.MIDTERM;
							break;
						case "INARREAR":
							iPaymentDateType = IFRS16PaymentDateType.INARREAR;
							break;
						}
						if (iPaymentDateType != null) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.PAYMENTDATETYPE);
							CombinationItem<IFRS16PaymentDateType> paymentDateType = CombinationItem
									.getNewCombinationItem(iPaymentDateType, settings);
							values.put(IFRS16ImportAssignmentType.PAYMENTDATETYPE, paymentDateType);

						}

						Double withoutValue = null;
						try {
							withoutValue = Double.valueOf(inputValues[17]);
						} catch (Exception ex) {

						}
						if (withoutValue != null) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.AMOUNTWITHOUTVALUEADDEDTAX);
							CombinationItem<Double> amntWithoutValue = CombinationItem
									.getNewCombinationItem(withoutValue, settings);
							values.put(IFRS16ImportAssignmentType.AMOUNTWITHOUTVALUEADDEDTAX, amntWithoutValue);
						}

						IFRS16VATRateType rateType = null;
						switch (inputValues[18]) {
						case "NULL":
							rateType = IFRS16VATRateType.NULL;
							break;
						case "FULLVAT":
							rateType = IFRS16VATRateType.FULLVAT;
							break;
						case "REDUCEDVAT":
							rateType = IFRS16VATRateType.REDUCEDVAT;
							break;
						case "NOVAT":
							rateType = IFRS16VATRateType.NOVAT;
							break;
						}
						if (rateType != null) {
							settings.getTypeList().add(IFRS16ImportAssignmentType.VATRATETYPE);
							CombinationItem<IFRS16VATRateType> vatRateType = CombinationItem
									.getNewCombinationItem(rateType, settings);
							values.put(IFRS16ImportAssignmentType.VATRATETYPE, vatRateType);

						}

						combinationLine.getDataMap().putAll(values);

						combinationLines.add(combinationLine);
					}

					InputCombination inputObject = new InputCombination(companyList, combinationLines, settings);
					allInputs.add(inputObject);
				} catch (Exception ex) {
					System.out.println(ex.toString());
					continue;
				}
			}
		} catch (Exception exception) {
			System.out.println(exception.toString());
		}

		return allInputs;

	}

}
