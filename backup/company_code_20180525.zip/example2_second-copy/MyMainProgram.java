package com.wuerth.phoenix.cis.university.example2.test.lemon;

import com.wuerth.phoenix.cis.university.example2.util.Scenario;
import com.wuerth.phoenix.cis.university.example2.test.lemon.EngineTestData;


public class MyMainProgram {

	public static void main(String[] args) {

		new EngineTestData("test1",0) {
			
			@Override
			public boolean check(Scenario scenario) {
				//checkImport(scenario);
				return true;
			}
		}.start();

	}

}
